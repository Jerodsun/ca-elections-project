November 6 Gubernatorial General Election - Official Election Results as of 12/6/2018.

Notes on the enclosed files:

20181106cv.txt:  This file contains information about each consolidated 
precinct,contest, candidate and statistics.  There are four types of 
records grouped under each contest and consolidated precinct.

1.  Registered Voters.
2.  Times Counted. 
3.  stats/candidate(label)or candidate name.
4.  Count Type.

Each of the above records has an associated field that identifies
the approprate value for that field.   

Registered voters = number of registered voters in the precinct
Times Counted = the number of ballots cast in the precinct.
Candidate name = number of votes the candidate received.
Count Type = Mail (Mail Ballot Voters), Polling and total votes

Each of these lines is repeated for each precinct and contest.

contest.txt:

This is a list of contest in the 20181106cv.txt with it's
contest_id.  You would use this table to isolate a contest in the 20180605cv.txt
file.

candidate.txt:

This is a list of candidates in the 20181106cv.txt with their
candidate_id.  You would use this table to isolate a candiate in the 20180605cv.txt
file.

Cons to Home Prec with BT.txt:

This is a list that identifies the
home precinct(s) that makeup the consolidated precinct (polling place) or (Absentee).
Mail ballots were counted back to their consolidated Polling place precinct or 
The mail ballot precinct (999XXX) XXX= ballot type are vote by mail precincts.  

Precdist-10-24-2018.txt

This is a home precinct to district.  Use this to locate which districts are associated
to a consolidation.


