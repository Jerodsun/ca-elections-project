November 4, 2014 - Gubernatorial General Election

************  OFFICIAL RESULTS - Certified 12/2/2014 ****************


Notes on the enclosed files:

201411cv.txt:  This file contains information about each consolidated 
precinct,contest, candidate and statistics.  There are four types of 
records grouped under each contest and consolidated precinct.

1.  Registered Voters.
2.  Times Counted. 
3.  stats/candidate(label)or candidate name.
4.  Count Type.

Each of the above records has an associated field that identifies
the approprate value for that field.   

Registered voters = number of registered voters in the precinct
Times Counted = the number of ballots cast in the precinct.
Candidate name = number of votes the candidate received.
Count Type = Mail (Mail Ballot Voters), Polling and total votes

Each of these lines is repeated for each precinct and contest.

contest.txt:

This is a list of contest in the 201411cv.txt with it's
contest_id.  You would use this table to isolate a contest in the 201411cvtxt.txt
file.

candidate.txt:

This is a list of candidates in the 201411cv.txt with their
candidate_id.  You would use this table to isolate a candiate in the 201411cvtxt.txt
file.

Contest-Candidate.txt:

This is a list of Candidate by Contest with ID's for both.  You might find a use when linking this to the canvass table.

97-Consolidation_to_home_precinct.txt:

This is a list that identifies the
home precinct(s) that makeup the consolidated precinct (polling place) or (Absentee).
Mail ballots were counted back to their consolidated Polling place precinct or 
The mail ballot precinct (999XXX) XXX= ballot type are vote by mail precincts.  

Precdist_AO_10-25-2014_E-15.txt 

This is a home precinct to district.  Use this to locate which districts are associated
to a consolidation.
